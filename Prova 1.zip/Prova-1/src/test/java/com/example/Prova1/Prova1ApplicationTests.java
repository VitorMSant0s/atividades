package com.example.Prova1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prova1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
